/* СОБРАНО: python unitka.py ext — из site/index.html (23.10.2026 11:32). Руками не править: формулы те же, что на сайте.
   LS — заглушка: значения по умолчанию берутся из окна расширения (UNITKA_DEFAULTS в формате сайта). FADS — реклама как ДРР %. */
"use strict";
var UNITKA_DEFAULTS = {};
const LS = { get(k, d) { return k === "defaults" ? UNITKA_DEFAULTS : d; }, set() {}, del() {} };
let FADS = "pct";
const clone = o => JSON.parse(JSON.stringify(o));
function num(v) {
  if (typeof v === "number") return isFinite(v) ? v : 0;
  if (v == null || v === "") return 0;
  const x = parseFloat(String(v).replace(/[\s  ]/g, "").replace(",", "."));
  return isFinite(x) ? x : 0;
}
const NF0 = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 });
const NF1 = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 1 });
const NF2 = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 2 });
const MINUS = "−";
function rub(x, sign) {
  if (x == null || !isFinite(x)) return "—";
  const a = Math.abs(x), s = (a < 100 ? NF1 : NF0).format(a);
  const neg = x < 0 && s !== "0";
  return (neg ? MINUS : (sign && x > 0 && s !== "0" ? "+" : "")) + s + " ₽";
}
function pct(x, d = 1, sign) {
  if (x == null || !isFinite(x)) return "—";
  const s = Math.abs(x * 100).toLocaleString("ru-RU", { minimumFractionDigits: d, maximumFractionDigits: d });
  const neg = x < 0 && /[1-9]/.test(s);
  return (neg ? MINUS : (sign && x > 0 && /[1-9]/.test(s) ? "+" : "")) + s + "%";
}
const cls = x => (x > 0.004 ? "pos" : x < -0.004 ? "neg" : "");
const tone = (v, good) => (v == null || !isFinite(v) ? "" : v < -0.00005 ? "neg" : v >= good - 0.00005 ? "pos" : "mid");
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
function inField(v) { const x = num(v); return Math.abs(x - Math.round(x)) < 1e-9 ? String(Math.round(x)) : String(Math.round(x * 100) / 100).replace(".", ","); }
const OZX = { proc: 0, lastPct: 0, lastMax: 0, nonloc: 0, xdock: 0 };
const MPS = {
  wb:   { name: "Wildberries", short: "WB", schemes: ["FBW", "FBS"],
          fees: Object.assign({ scheme: "FBW", comm: 25, acq: 0, logi: 60, logiPct: 0, back: 50, buyout: 90, stor: 3, accept: 0, other: 0, otherPct: 0, soinv: 0, spp: 0 }, OZX),
          acqHint: "у WB обычно уже внутри комиссии — ставьте 0", logiHint: "за одну доставку, с коэффициентом склада" },
  ozon: { name: "Ozon", short: "Ozon", schemes: ["FBO", "FBS", "rFBS"],
          fees: Object.assign({ scheme: "FBS", comm: 30, acq: 1, logi: 130, logiPct: 0, back: 95, buyout: 90, stor: 0, accept: 0, other: 0, otherPct: 0, soinv: 50, spp: 0 }, OZX),
          acqHint: "от цены покупателя", logiHint: "всё вместе или только базовый тариф — доплаты ниже" },
  ym:   { name: "Яндекс Маркет", short: "ЯМ", schemes: ["FBY", "FBS"],
          fees: Object.assign({ scheme: "FBS", comm: 15, acq: 1.6, logi: 0, logiPct: 7.35, back: 0, buyout: 90, stor: 0, accept: 0, other: 0, otherPct: 0, soinv: 0, spp: 0 }, OZX),
          acqHint: "приём платежа, от цены покупателя", logiHint: "₽ за доставку; процент — строкой ниже" }
};
const TAX = {
  ausn_d:  { name: "АУСН «Доходы»", rate: 8, kind: "income", nds: false },
  ausn_dr: { name: "АУСН «Доходы − расходы»", rate: 20, kind: "profit", min: 0.03, nds: false },
  usn_d:   { name: "УСН «Доходы»", rate: 6, kind: "income", nds: true },
  usn_dr:  { name: "УСН «Доходы − расходы»", rate: 15, kind: "profit", min: 0.01, nds: true },
  osno:    { name: "ОСНО (НДФЛ / на прибыль)", rate: 13, kind: "profit", min: 0, nds: true },
  custom:  { name: "Свой % от выручки", rate: 6, kind: "income", nds: false },
  none:    { name: "Не учитывать", rate: 0, kind: "none", nds: false }
};
const COMMON_KEYS = ["adsMode", "drr", "adsRub", "tax", "taxRate", "taxBase", "nds", "ndsDeduct", "target", "targetRoi", "perMonth"];
const SCH_KEYS = ["comm", "acq", "logi", "logiPct", "proc", "lastPct", "lastMax", "nonloc", "xdock", "back", "buyout", "stor", "accept"];
const pickSch = f => { const o = {}; SCH_KEYS.forEach(k => { if (f && f[k] !== undefined) o[k] = f[k]; }); return o; };
function defaults() {
  const d = LS.get("defaults", {});
  const fees = {};
  for (const k in MPS) fees[k] = Object.assign({}, MPS[k].fees, (d.fees || {})[k] || {});
  return Object.assign({ adsMode: "pct", drr: 10, adsRub: 0, tax: "ausn_d", taxRate: 8, taxBase: "sale", nds: 0, ndsDeduct: false, target: 10, targetRoi: 30, perMonth: 100 },
                       d.common || {}, { fees });
}
function newState(mp) {
  const s = Object.assign({ v: 2, name: "", mp: mp || "wb", price0: 1500, disc: 0, buy: 400, lotShip: 0, lotQty: 100, ff: 0, costOther: 0, vol: 0 }, defaults());
  for (const k in MPS) { if (!MPS[k].schemes.includes(s.fees[k].scheme)) s.fees[k].scheme = MPS[k].fees.scheme; }
  s.keep = {}; s.auto = {};
  for (const k in MPS) s.auto[k + "|" + s.fees[k].scheme] = pickSch(s.fees[k]);
  return s;
}
function fixState(s) {
  const base = newState(s && s.mp);
  s = Object.assign(base, s || {});
  for (const k in MPS) s.fees[k] = Object.assign({}, MPS[k].fees, (s.fees || {})[k] || {});
  for (const k in MPS) { const sc = s.fees[k].scheme; if (!MPS[k].schemes.includes(sc) && !(sc === "fact" && s.tar && s.tar.mp === k && s.tar.fact)) s.fees[k].scheme = MPS[k].fees.scheme; }
  if (!MPS[s.mp]) s.mp = "wb";
  if (!TAX[s.tax]) s.tax = "ausn_d";
  return s;
}
function calc(s, mp, p0) {
  mp = mp || s.mp;
  const f = s.fees[mp];
  const P0 = p0 == null ? num(s.price0) : p0;
  const disc = Math.min(99.9, Math.max(0, num(s.disc))) / 100;
  const P = P0 * (1 - disc);
  const Pb = P * (1 - num(f.spp) / 100);
  const qty = num(s.lotQty);
  const cost = num(s.buy) * (1 + num(s.agent) / 100) + (qty > 0 ? num(s.lotShip) / qty : 0) + num(s.ff) + num(s.costOther);
  const comm = P * num(f.comm) / 100;
  const acq = Pb * num(f.acq) / 100;
  const b = Math.min(100, Math.max(1, num(f.buyout) || 100)) / 100;
  const lastV = P * num(f.lastPct) / 100, last = num(f.lastMax) > 0 ? Math.min(lastV, num(f.lastMax)) : lastV;
  const fwd = num(f.logi) + P * num(f.logiPct) / 100 + num(f.proc) + last + P * num(f.nonloc) / 100 + num(f.xdock) * num(s.vol);
  const logi = fwd / b + (1 / b - 1) * num(f.back);
  const stor = num(f.stor) + num(f.accept);
  const other = num(f.other) + P * num(f.otherPct) / 100;
  const mpSum = comm + acq + logi + stor + other;
  const ads = s.adsMode === "rub" ? num(s.adsRub) : P * num(s.drr) / 100;
  const sys = TAX[s.tax] || TAX.none, rate = num(s.taxRate) / 100;
  const base = (s.taxBase === "buyer" ? Pb : P) * (1 - num(f.soinv) / 100);
  const ndsR = sys.nds ? num(s.nds) / 100 : 0;
  const ndsOut = ndsR > 0 ? base * ndsR / (1 + ndsR) : 0;
  const ndsIn = ndsR >= 0.1 && s.ndsDeduct ? (mpSum + ads) * 22 / 122 : 0;
  const inc = base - ndsOut, exp = cost + mpSum + ads - ndsIn;
  let incTax = 0;
  if (sys.kind === "income") incTax = inc * rate;
  else if (sys.kind === "profit") incTax = Math.max(rate * (inc - exp), (sys.min || 0) * inc, 0);
  const nds = ndsOut - ndsIn;
  const tax = incTax + nds;
  const profit = P - cost - mpSum - ads - tax;
  return { P0, P, Pb, cost, comm, acq, logi, stor, other, mpSum, ads, incTax, nds, tax, profit, b,
           gross: P - cost - mpSum, expenses: cost + mpSum + ads + tax,
           margin: P > 0 ? profit / P : NaN, roi: cost > 0 ? profit / cost : NaN, payout: P - mpSum };
}
function solveP0(s, mp, t) {
  const g = p0 => { const r = calc(s, mp, p0); return r.profit - t * r.P; };
  let lo = 0, hi = Math.max(100, num(s.price0) * 2);
  let i = 0;
  while (g(hi) < 0 && i++ < 40) hi *= 2;
  if (g(hi) < 0) return null;
  for (let k = 0; k < 90; k++) { const m = (lo + hi) / 2; if (g(m) < 0) lo = m; else hi = m; }
  return hi;
}
function priceTarget(s, mp, t) {
  const p0 = solveP0(s, mp, t);
  if (p0 == null) return null;
  return { p0, p: p0 * (1 - Math.min(99.9, num(s.disc)) / 100) };
}
function encodeState(s) {
  const b = new TextEncoder().encode(JSON.stringify(s));
  let bin = ""; b.forEach(x => bin += String.fromCharCode(x));
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function decodeState(t) {
  const bin = atob(t.replace(/-/g, "+").replace(/_/g, "/"));
  return JSON.parse(new TextDecoder().decode(Uint8Array.from(bin, c => c.charCodeAt(0))));
}
function unit(row) {
  const b = row.h || row, u = num(b.units), sales = num(b.sales);
  if (u <= 0 || sales <= 0) return null;
  const per = k => num(b[k]) / u;
  const x = { price: sales / u, comm: per("comm"), acq: per("acq"), logi: per("logi"), stor: per("stor"), ff: per("ff"), dop: per("dop"),
              loyal: per("loyal"), ads: per("ads") + per("ads2"), tax: per("tax"), cost: per("cost"), profit: per("profit"),
              units: row.h ? u / (num(row.h.n) || 1) : u, ub: u, src: row.h ? row.h.label : "" };
  const sum = x.comm + x.acq + x.logi + x.stor + x.ff + x.dop + x.loyal + x.ads + x.tax + x.cost;
  x.resid = x.price - sum - x.profit;      // если панель считает иначе — «прочее», чтобы факт совпал с панелью
  // в панели ФФ нет (у ЯМ — никогда): ставка из таблицы «Услуги Фулфилмента» (ffs), доукомплектовка ЯМ — из панелей ВБ/Озон (dops); прибыль юнитки меньше на них
  if (!(x.ff > 0.004) && num(row.ffs) > 0) { x.ff = num(row.ffs); x.profit -= x.ff; x.ffTab = true; }
  if (!(x.dop > 0.004) && num(row.dops) > 0) { x.dop = num(row.dops); x.profit -= x.dop; x.dopTab = true; }
  x.cR = x.comm / x.price; x.aR = x.acq / x.price; x.tR = x.tax / x.price; x.drr = x.ads / x.price;
  return x;
}
function at(x, p, adsMode) {
  const comm = x.cR * p, acq = x.aR * p, tax = x.tR * p, ads = adsMode === "pct" ? x.drr * p : x.ads;
  const fixed = x.logi + x.stor + x.ff + x.dop + x.loyal + x.resid + x.cost;
  const profit = p - comm - acq - tax - ads - fixed;
  return { p, comm, acq, tax, ads, profit, margin: profit / p, roi: x.cost > 0 ? profit / x.cost : NaN };
}
function factPrice(x, adsMode, m) {           // цена, при которой маржа = m
  const rate = x.cR + x.aR + x.tR + (adsMode === "pct" ? x.drr : 0);
  const fixed = x.logi + x.stor + x.ff + x.dop + x.loyal + x.resid + x.cost + (adsMode === "pct" ? 0 : x.ads);
  return 1 - rate - m > 0 ? fixed / (1 - rate - m) : null;
}
function factToState(mp, row, x, price) {
  const s = newState(mp), f = s.fees[mp];
  const r2 = v => Math.round(v * 100) / 100, p4 = v => Math.round(v * 1e6) / 1e4;      // рубли до копейки, проценты до 0,0001
  Object.assign(s, { name: row.a, price0: r2(price), disc: 0, buy: r2(x.cost), lotShip: 0, ff: r2(x.ff), costOther: r2(x.dop), vol: 0,
    tax: "ausn_d", taxRate: p4(x.tR), nds: 0, taxBase: "sale", perMonth: Math.round(x.units) });     // АУСН «Доходы» по ставке панели
  if (FADS === "pct") { s.adsMode = "pct"; s.drr = p4(x.drr); } else { s.adsMode = "rub"; s.adsRub = r2(x.ads); }
  const spp = row.spp > 0 && row.spp < 0.95 ? row.spp : 0;                          // СПП / соинвест с витрины (лист «Цены витрина» панели)
  Object.assign(f, OZX, { comm: p4(x.cR), acq: p4(x.aR / (1 - spp)), spp: p4(spp), logi: r2(x.logi), logiPct: 0, back: 0, buyout: 100,
    stor: r2(x.stor), accept: 0, other: r2(x.loyal + x.resid), otherPct: 0, soinv: 0, scheme: "fact" });
  // схема «По панели»: факт как продавали; тарифы схем этого товара (shemy.py) — для переключателя схемы
  s.tar = { mp, a: row.a, fact: true, src: x.src || "", t: row.t || null };
  s.auto = { [mp + "|fact"]: pickSch(f) };
  return s;
}
