/* Юнитка на карточке — окно расширения: пароль к факту и значения по умолчанию для чужих товаров (chrome.storage.local). */
"use strict";
const $ = s => document.querySelector(s);
const store = { get: k => chrome.storage.local.get(k).then(o => o[k]), set: (k, v) => chrome.storage.local.set({ [k]: v }) };
const msg = m => new Promise(r => chrome.runtime.sendMessage(m, x => { void chrome.runtime.lastError; r(x || {}); }));
const path = (o, p) => p.split(".").reduce((a, k) => (a == null ? a : a[k]), o);
const dt = s => { const d = new Date(s); return isNaN(d) ? "" : d.toLocaleString("ru-RU", { timeZone: "Europe/Moscow", day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }) + " МСК"; };
let D = null;

function showStatus(s) {
  const f = $("#stFact");
  if (s.fact) {
    const n = s.fact.n || {}, m = s.fact.month || {};
    f.innerHTML = `<span class="ok">✓ Факт открыт</span>: WB ${n.wb || 0} (${esc(String(m.wb || "").toLowerCase())}), Ozon ${n.ozon || 0} (${esc(String(m.ozon || "").toLowerCase())}) · обновлён ${dt(s.fact.updated)}`;
  } else if (s.factErr === "NEED_PASS") f.innerHTML = "Пароль не введён — наши товары будут считаться как чужие.";
  else if (s.factErr === "BAD_PASS") f.innerHTML = '<span class="bad">Пароль не подошёл.</span>';
  else f.innerHTML = '<span class="bad">Факт не загрузился:</span> ' + esc(s.factErr || s.error || "нет ответа");
  $("#stTar").innerHTML = s.tariffs ? `Тарифы WB: ${NF0.format(s.tariffs.n)} предметов · от ${dt(s.tariffs.updated)}` : '<span class="bad">Тарифы WB не загрузились:</span> ' + esc(s.tarErr || "");
}

async function init() {
  $("#tax").innerHTML = Object.entries(TAX).filter(([k]) => k !== "none").map(([k, t]) => `<option value="${k}">${esc(t.name)}</option>`).join("");
  D = UNITKA.merge(UNITKA.DEF, await store.get("defaults"));
  document.querySelectorAll("[data-d]").forEach(el => { const v = path(D, el.dataset.d); el.value = v == null ? "" : String(v); });
  if (await store.get("pass")) $("#pass").placeholder = "Пароль сохранён — можно сменить";
  showStatus(await msg({ t: "status" }));
}
let saveT = 0;
document.body.addEventListener("input", e => {
  const k = e.target.dataset.d; if (!k) return;
  const ks = k.split("."), last = ks.pop();
  const o = ks.reduce((a, x) => (a[x] = a[x] || {}), D);
  o[last] = e.target.value.trim();
  if (k === "tax") { D.taxRate = String(TAX[D.tax].rate); $('[data-d="taxRate"]').value = D.taxRate; }
  clearTimeout(saveT); saveT = setTimeout(() => store.set("defaults", D), 300);
});
$("#fPass").addEventListener("submit", async e => {
  e.preventDefault();
  const p = $("#pass").value.trim(); if (!p) return;
  $("#stFact").textContent = "Открываю…";
  const s = await msg({ t: "setPass", pass: p });
  $("#pass").value = "";
  showStatus(s);
});
$("#bRefresh").onclick = async () => { $("#stFact").textContent = "Обновляю…"; showStatus(await msg({ t: "refresh" })); };
init();
