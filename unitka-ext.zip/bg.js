/* Юнитка на карточке — фон: факт (зашифрован, как на сайте), открытые тарифы WB, card.json с basket-CDN.
   Токенов здесь нет: всё берётся с сайта https://asty7us-web.github.io/unitka/ и открытых CDN WB. */
"use strict";
const SITE = "https://asty7us-web.github.io/unitka/";
const FACT_TTL = 30 * 60e3, TAR_TTL = 6 * 3600e3;
const local = {
  get: k => chrome.storage.local.get(k).then(o => o[k]),
  set: (k, v) => chrome.storage.local.set({ [k]: v }),
  del: k => chrome.storage.local.remove(k)
};
const b64u8 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const u8b64 = u => { let s = ""; u.forEach(x => s += String.fromCharCode(x)); return btoa(s); };

/* ── факт панелей: fact.enc.json → AES-GCM (ключ PBKDF2 из пароля, как в site/index.html) ── */
let FACT = null, FACT_AT = 0;
async function loadFact(force) {
  if (!force && FACT && Date.now() - FACT_AT < FACT_TTL) return FACT;
  if (!force) {
    const ses = (await chrome.storage.session.get("fact")).fact;
    if (ses && Date.now() - ses.at < FACT_TTL) { FACT = ses.d; FACT_AT = ses.at; return FACT; }
  }
  const pass = await local.get("pass");
  if (!pass) throw new Error("NEED_PASS");
  const r = await fetch(SITE + "fact.enc.json?t=" + Date.now(), { cache: "no-store" });
  if (!r.ok) throw new Error("факт не загрузился с сайта (" + r.status + ")");
  const enc = await r.json();
  const kc = await local.get("kc");
  let plain = null;
  if (kc && kc.salt === enc.salt) {
    try {
      const key = await crypto.subtle.importKey("raw", b64u8(kc.k), "AES-GCM", false, ["decrypt"]);
      plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: b64u8(enc.iv) }, key, b64u8(enc.ct));
    } catch (e) { plain = null; }
  }
  if (!plain) {
    const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(pass), "PBKDF2", false, ["deriveKey"]);
    const key = await crypto.subtle.deriveKey({ name: "PBKDF2", hash: "SHA-256", salt: b64u8(enc.salt), iterations: enc.iter },
                                              base, { name: "AES-GCM", length: 256 }, true, ["decrypt"]);
    try { plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: b64u8(enc.iv) }, key, b64u8(enc.ct)); }
    catch (e) { await local.del("kc"); throw new Error("BAD_PASS"); }
    await local.set("kc", { salt: enc.salt, k: u8b64(new Uint8Array(await crypto.subtle.exportKey("raw", key))) });
  }
  FACT = JSON.parse(new TextDecoder().decode(plain)); FACT_AT = Date.now();
  await chrome.storage.session.set({ fact: { at: FACT_AT, d: FACT } });
  return FACT;
}
/* наш ли товар: WB — по nmID, Ozon — по SKU витрины. Наружу отдаём только эту строку. */
async function lookup(mp, id) {
  let f;
  try { f = await loadFact(); }
  catch (e) { return { need: e.message === "NEED_PASS" ? "pass" : e.message === "BAD_PASS" ? "bad" : "", error: e.message }; }
  const p = f.mp && f.mp[mp];
  const n = Number(id);
  const row = p ? p.rows.find(r => (mp === "wb" ? Math.round(Number(r.nm)) === n : Number(r.sku) === n)) : null;
  return { row: row || null, month: p ? p.month : "", updated: f.updated };
}

/* ── открытые тарифы WB (unitka.py tariffs кладёт их на сайт раз в сутки) ── */
async function tariffs() {
  const c = await local.get("tariffs");
  if (c && Date.now() - c.at < TAR_TTL) return c.d;
  try {
    const r = await fetch(SITE + "tariffs.json?t=" + Date.now(), { cache: "no-store" });
    if (!r.ok) throw new Error("тарифы не загрузились (" + r.status + ")");
    const d = await r.json();
    await local.set("tariffs", { at: Date.now(), d });
    return d;
  } catch (e) {
    if (c) return c.d;            // старые лучше, чем никаких
    throw e;
  }
}

/* ── card.json WB: предмет, артикул продавца, габариты упаковки ── */
function dimCm(v) {
  const m = String(v || "").replace(",", ".").match(/([\d.]+)\s*(мм|см|м)?/);
  if (!m) return null;
  let x = parseFloat(m[1]);
  if (m[2] === "мм") x /= 10; else if (m[2] === "м") x *= 100;
  return x > 0 ? x : null;
}
function parseCard(c) {
  const opts = (c.options || []).concat(...(c.grouped_options || []).map(g => g.options || []));
  const opt = n => { const o = opts.find(o => o.name === n); return o ? o.value : null; };
  const L = dimCm(opt("Длина упаковки")), W = dimCm(opt("Ширина упаковки")), H = dimCm(opt("Высота упаковки"));
  return { subjectId: (c.data || {}).subject_id || null, subj: c.subj_name || "", vendor: c.vendor_code || "", title: c.imt_name || "",
           dims: L && W && H ? [L, W, H] : null, volL: L && W && H ? Math.round(L * W * H) / 1000 : null,
           weight: opt("Вес с упаковкой (кг)") || opt("Вес товара с упаковкой (г)") || "" };
}
async function wbCard(nm, hint) {
  nm = Number(nm);
  const vol = Math.floor(nm / 1e5), part = Math.floor(nm / 1e3);
  const path = "/vol" + vol + "/part" + part + "/" + nm + "/info/ru/card.json";
  const get = async h => { const r = await fetch("https://" + h + path); if (!r.ok) throw new Error(r.status); return [h, await r.json()]; };
  const hosts = (await local.get("wbHosts")) || {};
  let res = null;
  for (const h of [hint, hosts[vol]].filter(Boolean)) { try { res = await get(h); break; } catch (e) {} }
  if (!res) {
    const all = [];
    for (let b = 1; b <= 99; b++) all.push("basket-" + String(b).padStart(2, "0") + ".wbbasket.ru");
    for (let i = 0; i < all.length && !res; i += 25) { try { res = await Promise.any(all.slice(i, i + 25).map(get)); } catch (e) {} }
  }
  if (!res) throw new Error("card.json WB не найден");
  if (hosts[vol] !== res[0]) { hosts[vol] = res[0]; await local.set("wbHosts", hosts); }
  return parseCard(res[1]);
}

/* ── окно расширения ── */
async function status() {
  const out = { hasPass: !!(await local.get("pass")) };
  try {
    const f = await loadFact();
    out.fact = { updated: f.updated, n: Object.fromEntries(Object.entries(f.mp || {}).map(([k, v]) => [k, v.rows.length])),
                 month: Object.fromEntries(Object.entries(f.mp || {}).map(([k, v]) => [k, v.month])) };
  } catch (e) { out.factErr = e.message; }
  try { const t = await tariffs(); out.tariffs = { updated: t.updated, n: Object.keys(t.wb.comm || {}).length }; }
  catch (e) { out.tarErr = e.message; }
  return out;
}

async function handle(m) {
  if (m.t === "lookup") return lookup(m.mp, m.id);
  if (m.t === "tariffs") return { d: await tariffs() };
  if (m.t === "wbcard") return { d: await wbCard(m.nm, m.hint) };
  if (m.t === "status") return status();
  if (m.t === "setPass") {
    await local.set("pass", String(m.pass || "").trim()); await local.del("kc");
    FACT = null; await chrome.storage.session.remove("fact");
    return status();
  }
  if (m.t === "refresh") { FACT = null; await chrome.storage.session.remove("fact"); await local.del("tariffs"); return status(); }
  throw new Error("неизвестный запрос");
}
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  // пароль и сброс — только из окна расширения (не из скриптов на страницах WB/Ozon)
  const fromExt = String(sender.url || "").startsWith(chrome.runtime.getURL(""));
  if (!fromExt && ["setPass", "refresh", "status"].includes(m && m.t)) { reply({ error: "только из окна расширения" }); return false; }
  handle(m).then(reply, e => reply({ error: String(e && e.message || e) }));
  return true;
});
