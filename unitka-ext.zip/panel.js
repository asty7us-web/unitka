/* Юнитка на карточке — панель под ценой (общая для WB и Ozon).
   Формулы — core.js (дословно с сайта): наш товар → factToState() из факта панели, чужой → newState() + тарифы + ввод.
   Чего не хватает — просим ввести, нулями не подменяем. */
"use strict";
const UNITKA = (() => {
  const SITE = "https://asty7us-web.github.io/unitka/";
  const DEF = { tax: "ausn_d", taxRate: 8, drr: 10, target: 10,
                wb: { scheme: "FBS", buyout: 90, spp: "" }, ozon: { scheme: "FBS", buyout: 90, spp: "" } };
  const LBL = { wb: { spp: "СПП", alt: "с WB Кошельком" }, ozon: { spp: "скидка Ozon", alt: "с Ozon Банком" } };
  const NEED = { cost: "себестоимость", spp: "СПП", comm: "комиссию", logi: "логистику", price: "цену (не нашёл на странице)" };
  const r2 = v => Math.round(v * 100) / 100, p4 = v => Math.round(v * 1e6) / 1e4;
  const has = v => v !== undefined && v !== null && String(v).trim() !== "" && isFinite(parseFloat(String(v).replace(",", ".")));
  const send = m => new Promise(res => {
    try { chrome.runtime.sendMessage(m, r => { void chrome.runtime.lastError; res(r || { error: "расширение не ответило — обновите страницу" }); }); }
    catch (e) { res({ error: "расширение обновилось — обновите страницу" }); }
  });
  const store = { get: k => chrome.storage.local.get(k).then(o => o[k]), set: (k, v) => chrome.storage.local.set({ [k]: v }) };
  const merge = (a, b) => { const o = JSON.parse(JSON.stringify(a)); for (const k in b || {}) o[k] = o[k] && typeof o[k] === "object" && b[k] && typeof b[k] === "object" ? Object.assign(o[k], b[k]) : b[k]; return o; };
  const money = s => { const m = String(s || "").replace(/[\s   ]/g, "").match(/(\d+(?:[.,]\d+)?)₽/); return m ? parseFloat(m[1].replace(",", ".")) : null; };

  /* окно расширения → «значения по умолчанию» в формате сайта (их читает newState() из core.js) */
  function siteDefaults(d) {
    return { common: { adsMode: "pct", drr: num(d.drr), tax: TAX[d.tax] ? d.tax : "ausn_d", taxRate: has(d.taxRate) ? num(d.taxRate) : (TAX[d.tax] || TAX.ausn_d).rate, target: num(d.target) },
             fees: { wb: { scheme: d.wb.scheme === "FBW" ? "FBW" : "FBS", buyout: num(d.wb.buyout) || 90 },
                     ozon: { scheme: ["FBO", "FBS", "rFBS"].includes(d.ozon.scheme) ? d.ozon.scheme : "FBS", buyout: num(d.ozon.buyout) || 90 } } };
  }

  /* комиссия и логистика чужого товара WB — по открытым тарифам (tariffs.json сайта) */
  function wbAuto(card, T, scheme) {
    const out = {};
    if (!T || !T.wb || !card) return out;
    const w = T.wb, sch = scheme === "FBW" ? "FBW" : "FBS";
    const c = card.subjectId && w.comm[String(card.subjectId)];
    const v = c && c[sch === "FBW" ? 0 : 1];
    if (v != null) { out.comm = v; out.commSrc = "тариф WB для «" + card.subj + "», " + sch; }
    const b = w.box && w.box[sch];
    if (b && card.volL) {
      const L = card.volL;
      let fwd;
      if (L <= 1) { const t = (w.small || []).find(x => L <= x[0]); fwd = t ? t[1] * b.coef / 100 : b.base; }
      else fwd = b.base + (L - 1) * b.liter;
      out.logi = r2(fwd); out.logiSrc = "оценка: " + NF2.format(L) + " л, склад «" + b.wh + "» ×" + NF2.format(b.coef / 100);
    }
    return out;
  }

  /* вводные → состояние расчёта сайта → calc() */
  function model(c) {
    const { mp, page, d } = c, user = c.user || {}, miss = [], notes = [];
    UNITKA_DEFAULTS = siteDefaults(d);
    const row = c.fact && c.fact.row, x = row ? unit(row) : null;
    const site = page && page.price || null;
    const sppIn = has(user.spp) ? num(user.spp) : has(d[mp].spp) ? num(d[mp].spp) : null;
    let s, f, kind, spp = null, inputs = [];
    if (x) {
      kind = "fact";
      const now = num(row.now) || null;
      let P = now;
      if (!P) {                                         // в факте нет цены кабинета — как у чужого: от цены сайта и СПП
        inputs = ["spp"];
        if (sppIn == null) miss.push("spp");
        if (!site) miss.push("price");
        if (site && sppIn != null) { P = site / (1 - Math.min(95, sppIn) / 100); spp = sppIn; }
      }
      s = factToState(mp, row, x, P || x.price);
      f = s.fees[mp];
      if (now && site) {
        spp = r2((1 - site / now) * 100);
        // покупатель платит цену сайта (как в «Расчёте» сайта); эквайринг пересчитан, чтобы в ₽ остался как в факте
        if (spp > 0 && spp < 95) { f.spp = spp; f.acq = p4(x.aR / (1 - spp / 100)); }
        else if (spp < 0) notes.push("цена на сайте выше цены кабинета — проверьте цену в кабинете");
      } else if (spp != null) { f.spp = spp; f.acq = p4(x.aR / (1 - spp / 100)); }
    } else {
      kind = "est";
      inputs = ["cost", "spp", "comm", "logi"];
      s = newState(mp); f = s.fees[mp];
      Object.assign(s, { name: c.name || "", disc: 0, lotShip: 0, ff: 0, costOther: 0, vol: 0 });
      if (!site) miss.push("price");
      if (sppIn == null) miss.push("spp"); else spp = sppIn;
      if (site && sppIn != null) { s.price0 = r2(site / (1 - Math.min(95, sppIn) / 100)); f.spp = sppIn; }
      if (has(user.cost)) s.buy = num(user.cost); else miss.push("cost");
      const auto = c.auto || {};
      const comm = has(user.comm) ? num(user.comm) : auto.comm, logi = has(user.logi) ? num(user.logi) : auto.logi;
      if (comm == null) miss.push("comm"); else f.comm = comm;
      if (logi == null) miss.push("logi"); else f.logi = logi;
      if (mp === "wb") { f.acq = 0; if (f.scheme === "FBS") f.stor = 0; }
      if (row) notes.push("наш товар, но продаж в факте за " + String(c.fact.month || "месяц").toLowerCase() + " нет — считаю по тарифам");
    }
    const ok = !miss.length, r = calc(s), be = ok ? priceTarget(s, mp, 0) : null;
    return { kind, s, f, r, be, ok, miss, notes, spp, x, row, inputs, t: num(s.target) / 100 };
  }

  /* ───────── вид ───────── */
  const CSS = `
:host{all:initial;display:block}
.u{font:13px/1.35 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#1d1d1b;background:#fff;border:1.5px solid #2a78d6;border-radius:14px;
  padding:10px 12px;box-shadow:0 2px 12px rgba(0,0,0,.07);box-sizing:border-box;width:100%;text-align:left}
.u *{box-sizing:border-box}
.hd{display:flex;align-items:center;gap:5px}
.lg{width:20px;height:20px;border-radius:6px;background:#2a78d6;color:#fff;font-weight:700;display:grid;place-items:center;font-size:12px;flex:none}
.ttl{font-weight:700;font-size:13.5px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tag{font-size:11px;padding:1px 6px;border-radius:6px;background:#e6f0fc;color:#1f5fae;font-weight:600;white-space:nowrap;flex:none}
.tag.est{background:#f0efec;color:#52514e}
.sp{flex:1}
button{font:inherit;cursor:pointer}
.go{border:0;background:#2a78d6;color:#fff;border-radius:8px;padding:5px 8px;font-weight:600;font-size:12px;white-space:nowrap;flex:none}
.go[disabled]{background:#c9c8c2;cursor:default}
.mn{border:0;background:#f0efec;border-radius:8px;width:26px;height:26px;color:#52514e;font-weight:700;flex:none;padding:0}
.pr{margin-top:7px;color:#52514e;display:grid;grid-template-columns:auto 1fr;gap:1px 8px}
.pr b{color:#1d1d1b;font-variant-numeric:tabular-nums}
.pr .m{color:#7a7873}
.in{display:grid;grid-template-columns:1fr 1fr;gap:6px 8px;margin-top:8px}
.in label{display:flex;flex-direction:column;gap:2px;font-size:11.5px;color:#52514e;min-width:0}
.in .box{display:flex;align-items:center;background:#f4f4f1;border:1px solid #e1e0d9;border-radius:8px;height:30px;padding:0 8px}
.in .box:focus-within{border-color:#2a78d6;background:#fff}
.in .box.need{border-color:#c62f2f;background:#fbeaea}
.in input{border:0;outline:0;background:transparent;width:100%;min-width:0;font:inherit;font-size:14px;text-align:right;color:#1d1d1b;padding:0}
.in i{font-style:normal;color:#7a7873;margin-left:4px}
.in small{color:#8a8476;font-size:10.5px;line-height:1.2;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hero{margin-top:9px;display:flex;align-items:baseline;justify-content:space-between;gap:8px;background:#f4f4f1;border-radius:10px;padding:7px 10px}
.hero span{color:#52514e;font-size:12px}
.hero b{font-size:22px;font-weight:750;letter-spacing:-.01em;font-variant-numeric:tabular-nums}
.kp{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:6px}
.k{background:#f4f4f1;border-radius:10px;padding:6px 8px;min-width:0}
.k b{display:block;font-size:15px;font-variant-numeric:tabular-nums;white-space:nowrap}
.k span{font-size:11px;color:#52514e;display:block;line-height:1.2}
.pos{color:#006300!important}.neg{color:#c62f2f!important}.mid{color:#946200!important}
.rows{display:grid;grid-template-columns:1fr auto;gap:2px 10px;margin-top:8px;font-variant-numeric:tabular-nums}
.rows .v{text-align:right;font-weight:600;white-space:nowrap}
.rows .m{color:#7a7873;font-weight:400}
.warn{margin-top:8px;background:#fbeaea;color:#8a1f1f;border-radius:8px;padding:6px 8px;font-size:12.5px;font-weight:600}
.note{margin-top:7px;font-size:11px;color:#7a7873;line-height:1.35}
.err{margin-top:7px;font-size:12px;color:#8a1f1f}
.u.min .body{display:none}
`;
  let sheet = null;
  function mount(host) {
    const root = host.attachShadow({ mode: "open" });
    try { if (!sheet) { sheet = new CSSStyleSheet(); sheet.replaceSync(CSS); } root.adoptedStyleSheets = [sheet]; }
    catch (e) { const st = document.createElement("style"); st.textContent = CSS; root.appendChild(st); }
    const box = document.createElement("div"); box.className = "u"; root.appendChild(box);
    return box;
  }

  function priceRows(c, m) {
    const L = LBL[c.mp], p = c.page || {};
    const rows = [];
    const nm = m.kind === "fact" ? m.row.a : c.name;
    if (nm) rows.push([m.kind === "fact" || c.mp === "wb" ? "Артикул" : "Товар", `<b title="${esc(nm)}" style="overflow-wrap:anywhere">${esc(nm)}</b>`]);
    rows.push(["На сайте", p.price ? `<b>${rub(p.price)}</b>` + (p.alt && Math.abs(p.alt - p.price) >= 1 ? ` <span class="m">· ${L.alt} ${rub(p.alt)}</span>` : "") : '<span class="neg">не нашёл</span>']);
    const cab = m.kind === "fact" && num(m.row.now) > 0, known = cab || (m.spp != null && p.price);
    rows.push(["До " + (c.mp === "wb" ? "СПП" : "скидки Ozon"), known
      ? `<b>${rub(m.r.P)}</b>` + (m.spp != null ? ` <span class="m">· ${L.spp} ${NF1.format(Math.max(0, m.spp))}%</span>` : "") + (cab ? ' <span class="m">· из кабинета</span>' : "")
      : '<span class="neg">нужна ' + L.spp + "</span>"]);
    return rows.map(([a, b]) => `<span>${a}</span><span>${b}</span>`).join("");
  }
  function outHTML(c, m) {
    const r = m.r, f = m.f, t = m.t;
    if (!m.ok) {
      return `<div class="warn">Заполните ${m.miss.map(k => NEED[k]).join(", ")} — без ${m.miss.length > 1 ? "них" : "этого"} прибыль не посчитать.</div>`;
    }
    const taxName = m.kind === "fact" ? "Налог " + pct(m.x.tR) : (TAX[m.s.tax] || TAX.none).name.replace(/«|»/g, "") + (TAX[m.s.tax].kind !== "none" ? " " + NF2.format(num(m.s.taxRate)) + "%" : "");
    const be = m.be, sppK = 1 - num(f.spp) / 100;
    const rows = [
      [`Комиссия ${NF2.format(num(f.comm))}%`, rub(r.comm)],
      r.acq >= 0.5 ? ["Эквайринг", rub(r.acq)] : null,
      [`Логистика <span class="m">${m.kind === "fact" ? "· факт на 1 шт" : "· выкуп " + NF0.format(r.b * 100) + "%"}</span>`, rub(r.logi)],
      r.stor + r.other >= 0.5 ? ["Хранение и прочее", rub(r.stor + r.other)] : null,
      ["Себестоимость", rub(r.cost)],
      [taxName, rub(r.tax)],
      [`Реклама <span class="m">· ДРР ${NF1.format(num(m.s.drr))}%</span>`, rub(r.ads)]
    ].filter(Boolean);
    return `
      <div class="hero"><span>${r.profit < 0 ? "Убыток" : "Прибыль"} с 1 шт</span><b class="${tone(r.margin, t)}">${rub(r.profit)}</b></div>
      <div class="kp">
        <div class="k"><b class="${tone(r.margin, t)}">${pct(r.margin)}</b><span>маржа · цель ${NF1.format(t * 100)}%</span></div>
        <div class="k"><b class="${tone(r.roi, num(m.s.targetRoi) / 100)}">${pct(r.roi, 0)}</b><span>ROI</span></div>
        <div class="k"><b>${be ? rub(be.p) : "—"}</b><span>безубыточность${be && sppK < 1 ? "<br>на сайте " + rub(be.p * sppK) : ""}</span></div>
      </div>
      <div class="rows">${rows.map(([a, b]) => `<span>${a}</span><span class="v">${b}</span>`).join("")}</div>`;
  }
  function noteHTML(c, m) {
    const parts = [];
    if (m.kind === "fact") {
      const upd = c.fact.updated ? new Date(c.fact.updated) : null;
      parts.push(`Наш товар: факт панели за ${esc(m.x.src || String(c.fact.month || "").toLowerCase())} (${NF0.format(m.x.ub)} шт) — комиссия, налог, ДРР в % от цены, логистика и себестоимость в ₽ на 1 шт` +
        (upd ? `; цена кабинета на ${upd.toLocaleString("ru-RU", { timeZone: "Europe/Moscow", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })} МСК` : "") + ".");
    } else {
      parts.push(c.mp === "wb" ? "Чужой товар: комиссия и логистика — по открытым тарифам WB, налог, ДРР и выкуп — из настроек расширения." :
                                 "Чужой товар: комиссию запоминаю по категории, логистику — по товару; налог, ДРР и выкуп — из настроек расширения.");
    }
    m.notes.filter(Boolean).forEach(n => parts.push(esc(n)));
    if (c.err) parts.push('<span class="neg">' + esc(c.err) + "</span>");
    return parts.join("<br>");
  }

  /* ───────── цикл: товар на странице → данные → панель ───────── */
  function run(A) {
    let cur = null, host = null, box = null, busy = false, token = 0;
    const key = id => "p:" + A.mp + ":" + id;

    function attach() {
      if (!host) { host = document.createElement("div"); host.id = "unitka-ext"; box = mount(host); }
      const a = A.anchor();
      if (a) {
        if (host.previousElementSibling !== a || host.parentElement !== a.parentElement) a.insertAdjacentElement("afterend", host);
        host.style.cssText = "display:block;margin:12px 0;position:relative;z-index:5";
      } else if (!host.isConnected || host.parentElement !== document.body) {
        document.body.appendChild(host);
        host.style.cssText = "display:block;position:fixed;right:16px;bottom:16px;width:380px;max-width:calc(100vw - 32px);z-index:2147483646";
      }
    }
    function skeleton(c) {
      box.innerHTML = `<div class="hd"><span class="lg">Ю</span><span class="ttl">Юнитка</span><span class="tag est" data-o="tag">считаю…</span><span class="sp"></span>
        <button class="go" data-o="go" disabled>В Юнитку ↗</button><button class="mn" data-o="mn" title="Свернуть">–</button></div>
        <div class="body"><div class="pr" data-o="pr"></div><div class="in" data-o="in" hidden></div><div data-o="out"></div><div class="note" data-o="note"></div></div>`;
      box.querySelector('[data-o="mn"]').onclick = async () => {
        const on = !box.classList.contains("min"); box.classList.toggle("min", on);
        box.querySelector('[data-o="mn"]').textContent = on ? "+" : "–"; await store.set("collapsed", on);
      };
      box.querySelector('[data-o="go"]').onclick = () => { if (c.m && c.m.ok) window.open(SITE + "#c=" + encodeState(c.m.s), "_blank", "noopener"); };
      store.get("collapsed").then(v => { if (v) { box.classList.add("min"); box.querySelector('[data-o="mn"]').textContent = "+"; } });
    }
    function inputs(c, m) {
      const el = box.querySelector('[data-o="in"]');
      if (!m.inputs.length) { el.hidden = true; el.innerHTML = ""; return; }
      if (el.dataset.k === m.inputs.join()) return;
      el.dataset.k = m.inputs.join(); el.hidden = false;
      const L = LBL[c.mp], u = c.user || {}, auto = c.auto || {};
      const val = k => has(u[k]) ? u[k] : k === "spp" && has(c.d[c.mp].spp) ? c.d[c.mp].spp : (k === "comm" || k === "logi") && auto[k] != null ? auto[k] : "";
      const F = {
        cost: ["Себестоимость 1 шт", "₽", "закупка + доставка + ФФ"],
        spp: [L.spp[0].toUpperCase() + L.spp.slice(1), "%", has(u.spp) ? "ваш ввод" : has(c.d[c.mp].spp) ? "из настроек" : "на сайте не видна"],
        comm: ["Комиссия", "%", auto.commSrc || (c.mp === "ozon" ? "запомню для категории" : "нет тарифа — введите")],
        logi: ["Логистика за доставку", "₽", auto.logiSrc || (c.mp === "ozon" ? "запомню для товара" : "нет габаритов — введите")]
      };
      el.innerHTML = m.inputs.map(k => `<label><span>${F[k][0]}</span><span class="box" data-b="${k}"><input data-k="${k}" inputmode="decimal" value="${esc(val(k) === "" ? "" : inField(val(k)))}"><i>${F[k][1]}</i></span><small title="${esc(F[k][2])}">${esc(F[k][2])}</small></label>`).join("");
      el.oninput = async e => {
        const k = e.target.dataset.k; if (!k) return;
        const v = e.target.value.trim();
        c.user = Object.assign({}, c.user);
        if (v === "") delete c.user[k]; else c.user[k] = v;
        paint(c);
        await store.set(key(c.id), c.user);
        if (c.mp === "ozon" && k === "comm" && c.info && c.info.catId) {
          const ck = "c:ozon:" + c.info.catId, cat = Object.assign({}, await store.get(ck)); if (v === "") delete cat.comm; else cat.comm = v;
          cat.name = c.info.catName || ""; await store.set(ck, cat);
        }
      };
    }
    function paint(c) {
      if (!box || c !== cur) return;
      if (c.fatal) {
        box.querySelector('[data-o="tag"]').textContent = "нет данных";
        box.querySelector('[data-o="out"]').innerHTML = `<div class="err">${esc(c.fatal)}</div>`;
        return;
      }
      const m = c.m = model(c);
      const tag = box.querySelector('[data-o="tag"]');
      tag.className = "tag" + (m.kind === "fact" ? "" : " est");
      tag.textContent = m.kind === "fact" ? "наш товар" : "чужой";
      tag.title = m.kind === "fact" ? m.row.a : (c.name || "");
      const go = box.querySelector('[data-o="go"]');
      go.disabled = !m.ok; go.title = m.ok ? "Открыть этот расчёт на сайте Юнитки (вкладка «Расчёт»)" : "Сначала заполните поля";
      box.querySelector('[data-o="pr"]').innerHTML = priceRows(c, m);
      inputs(c, m);
      box.querySelectorAll("[data-b]").forEach(b => b.classList.toggle("need", m.miss.includes(b.dataset.b)));
      box.querySelector('[data-o="out"]').innerHTML = outHTML(c, m);
      box.querySelector('[data-o="note"]').innerHTML = noteHTML(c, m);
      host.dataset.unitka = JSON.stringify({ id: c.id, mp: c.mp, kind: m.kind, ok: m.ok, miss: m.miss, profit: m.ok ? m.r.profit : null,
        margin: m.ok ? m.r.margin : null, roi: m.ok ? m.r.roi : null, be: m.be ? m.be.p : null, P: m.r.P, Pb: m.r.Pb, site: c.page && c.page.price,
        link: m.ok ? SITE + "#c=" + encodeState(m.s) : null, name: m.kind === "fact" ? m.row.a : c.name });
    }
    async function load(c) {
      const my = ++token;
      skeleton(c);
      c.d = merge(DEF, await store.get("defaults"));
      const [fact, info, T, user] = await Promise.all([
        send({ t: "lookup", mp: A.mp, id: c.id }),
        A.info(c.id).catch(e => ({ err: String(e && e.message || e) })),
        A.mp === "wb" ? send({ t: "tariffs" }) : Promise.resolve(null),
        store.get(key(c.id))
      ]);
      if (my !== token) return;
      c.fact = fact && !fact.error ? fact : { row: null };
      c.info = info || {}; c.user = user || {}; c.T = T && T.d;
      c.name = c.info.name || "";
      c.page = c.info.page || (A.price ? A.price() : null);
      const errs = [];
      if (fact && fact.need === "pass") errs.push("Факт не открыт: введите пароль в окне расширения (значок «Ю» на панели браузера).");
      else if (fact && fact.need === "bad") errs.push("Пароль к факту не подошёл — поправьте в окне расширения.");
      else if (fact && fact.error) errs.push("Факт не загрузился: " + fact.error);
      if (c.info.err) errs.push("Карточка: " + c.info.err);
      if (A.mp === "wb" && T && T.error) errs.push("Тарифы WB: " + T.error);
      c.err = errs.join(" ");
      if (A.mp === "wb") c.auto = wbAuto(c.info.card, c.T, siteDefaults(c.d).fees.wb.scheme);
      if (A.mp === "ozon" && c.info.catId) {
        const cat = await store.get("c:ozon:" + c.info.catId);
        c.auto = {};
        if (cat && has(cat.comm)) { c.auto.comm = num(cat.comm); c.auto.commSrc = "как вводили для «" + (c.info.catName || "категории") + "»"; }
        else c.auto.commSrc = "запомню для «" + (c.info.catName || "категории") + "»";
      }
      if (my !== token) return;
      paint(c);
    }
    async function tick() {
      if (busy) return; busy = true;
      try {
        const id = A.id();
        if (!id) { if (host) host.remove(); cur = null; token++; return; }
        attach();
        if (!cur || cur.id !== id) { cur = { id, mp: A.mp }; await load(cur); return; }
        if (A.price && cur.m) {
          const p = A.price();
          if (p && p.price && (!cur.page || p.price !== cur.page.price || p.alt !== cur.page.alt)) { cur.page = p; paint(cur); }
        }
      } catch (e) { console.warn("Юнитка:", e); }
      finally { busy = false; }
    }
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === "local" && cur && (ch.defaults || ch.pass)) { const id = cur.id; cur = { id, mp: A.mp }; load(cur); }
    });
    tick(); setInterval(tick, 1500);
  }
  return { run, money, send, has, merge, DEF };
})();
