/* Юнитка на карточке — Ozon: SKU из адреса, цена/название/категория из composer-api страницы (обычный fetch с куками). */
"use strict";
(() => {
  const id = () => { const m = location.pathname.match(/^\/product\/(?:[^/]*-)?(\d{5,})\/?$/); return m ? m[1] : null; };
  const anchor = () => document.querySelector('[data-widget="webPrice"]');
  async function composer(path) {
    for (const base of ["/api/composer-api.bx/page/json/v2?url=", "/api/entrypoint-api.bx/page/json/v2?url="]) {
      try {
        const r = await fetch(base + encodeURIComponent(path), { credentials: "include", headers: { Accept: "application/json" } });
        const j = JSON.parse(await r.text());
        if (j && j.widgetStates) return j;
      } catch (e) { /* страница-проверка или сбой — пробуем другой адрес */ }
    }
    return null;
  }
  function domPrice() {
    const w = anchor(); if (!w) return null;
    const v = [...w.querySelectorAll("*")].filter(e => /₽/.test(e.textContent) && ![...e.children].some(ch => /₽/.test(ch.textContent)))
      .map(e => UNITKA.money(e.textContent)).filter(Boolean);
    const u = [...new Set(v)].sort((a, b) => a - b);
    if (u.length >= 3) return { price: u[1], alt: u[0], old: u[u.length - 1] };
    if (u.length === 2) return { price: u[0], alt: null, old: u[1] };
    return u.length ? { price: u[0], alt: null, old: null } : null;
  }
  async function info(sku) {
    const j = await composer(location.pathname);       // без ?__rr=… — иначе Ozon отдаёт страницу-проверку вместо JSON
    let page = null, name = "", catId = null, catName = "";
    if (j) {
      const ws = j.widgetStates;
      const get = p => { const k = Object.keys(ws).find(x => x.startsWith(p)); try { return k ? JSON.parse(ws[k]) : null; } catch (e) { return null; } };
      const wp = get("webPrice-");
      if (wp && wp.isAvailable !== false) {
        const price = UNITKA.money(wp.price), card = UNITKA.money(wp.cardPrice), old = UNITKA.money(wp.originalPrice);
        if (price || card) page = { price: price || card, alt: price && card && card !== price ? card : null, old: old || null };
      }
      const h = get("webProductHeading-"); if (h && h.title) name = h.title;
      try { const t = JSON.parse(j.layoutTrackingInfo || "{}"); catId = t.categoryId || null; catName = t.categoryName || ""; } catch (e) {}
    }
    if (!page) page = domPrice();
    if (!name) { const h1 = document.querySelector('[data-widget="webProductHeading"] h1'); name = h1 ? h1.textContent : ""; }
    name = String(name).trim();
    return { page, name: (name.length > 90 ? name.slice(0, 88) + "…" : name) + " · SKU " + sku, catId, catName };
  }
  UNITKA.run({ mp: "ozon", id, anchor, info, price: null });
})();
