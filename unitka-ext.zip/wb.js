/* Юнитка на карточке — Wildberries: nmID из адреса, цена из блока цены, card.json (предмет, габариты) через фон. */
"use strict";
(() => {
  const id = () => { const m = location.pathname.match(/\/catalog\/(\d+)\/detail\.aspx/); return m ? m[1] : null; };
  const vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  // блок цены справа (не верхняя липкая строка productLine)
  const block = () => [...document.querySelectorAll('[class*="priceBlock--"]')].find(el => !el.closest('[class*="productLine"]') && vis(el)) || null;
  const anchor = () => { const b = block(); return b ? b.closest('[class*="productPrice--"]') || b : null; };
  const leafs = root => [...root.querySelectorAll("*")].filter(e => /₽/.test(e.textContent) && ![...e.children].some(ch => /₽/.test(ch.textContent)));
  function price() {
    const b = block(); if (!b) return null;
    const val = el => (el ? UNITKA.money(el.textContent) : null);
    const wallet = val(b.querySelector('[class*="WalletPrice"],[class*="walletPrice"]'));
    const main0 = val(b.querySelector("ins"));
    const all = leafs(b).map(e => UNITKA.money(e.textContent)).filter(Boolean);
    const old = all.length ? Math.max(...all) : null;
    const main = main0 || all.find(v => v !== wallet && v !== old) || wallet || all[0] || null;
    return main ? { price: main, alt: wallet && wallet !== main ? wallet : null, old: old && old > main ? old : null } : null;
  }
  async function info(nm) {
    // хост basket — из того, что страница уже грузила; нет — фон переберёт basket-01…99
    const u = performance.getEntriesByType("resource").map(x => x.name).find(s => s.includes("/" + nm + "/info/ru/card.json") || s.includes("/" + nm + "/images/"));
    const r = await UNITKA.send({ t: "wbcard", nm, hint: u ? new URL(u).host : null });
    if (r.error) throw new Error(r.error);
    const card = r.d;
    return { card, name: card.vendor || card.title || "", page: price() };
  }
  UNITKA.run({ mp: "wb", id, anchor, price, info });
})();
